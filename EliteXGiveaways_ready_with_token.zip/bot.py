# EliteXGiveaways - ready-to-deploy Telegram bot
# Required environment variable:
# BOT_TOKEN = your BotFather token
# Optional:
# ADMIN_ID = your Telegram numeric user ID

import os
import json
import random
from datetime import datetime, timedelta, timezone

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes,
)

TOKEN = os.getenv("BOT_TOKEN", "8888458288:AAE3MDPtJNxpRYLmIdGsUsKN63FPJD4ahA")
ADMIN_ID = os.getenv("ADMIN_ID")
DATA_FILE = "giveaways.json"

if not TOKEN:
    raise RuntimeError("BOT_TOKEN is missing. Add BOT_TOKEN in your hosting panel.")

try:
    ADMIN_ID = int(ADMIN_ID) if ADMIN_ID else None
except ValueError:
    raise RuntimeError("ADMIN_ID must be a numeric Telegram user ID.")


def load_data():
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {"active": None}


def save_data():
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


data = load_data()


def admin(user_id):
    return ADMIN_ID is not None and user_id == ADMIN_ID


def giveaway_text(g):
    end = datetime.fromisoformat(g["end"])
    return (
        f"🎉 {g['title']}\n\n"
        f"🎁 Prize: {g['prize']}\n"
        f"👥 Participants: {len(g['participants'])}\n"
        f"⏰ Ends: {end.strftime('%Y-%m-%d %H:%M UTC')}"
    )


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    buttons = [
        [InlineKeyboardButton("🎁 View Giveaway", callback_data="view")],
        [InlineKeyboardButton("ℹ️ Help", callback_data="help")],
    ]
    await update.message.reply_text(
        "👑 Welcome to EliteXGiveaways!\n\n"
        "Join giveaways and get a chance to win prizes.",
        reply_markup=InlineKeyboardMarkup(buttons),
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "📚 EliteXGiveaways Commands\n\n"
        "/start - Start bot\n"
        "/giveaway - View active giveaway\n"
        "/newgiveaway PRIZE MINUTES TITLE - Create giveaway (admin)\n"
        "/endgiveaway - End giveaway (admin)\n\n"
        "Example:\n"
        "/newgiveaway TG_Premium 60 EliteX Premium Giveaway"
    )


async def show_giveaway_message(message, context):
    g = data.get("active")

    if not g:
        await message.reply_text("🎁 There is no active giveaway.")
        return

    end = datetime.fromisoformat(g["end"])
    if end <= datetime.now(timezone.utc):
        await finish_giveaway(context)
        await message.reply_text("⏰ The giveaway has ended.")
        return

    buttons = [
        [InlineKeyboardButton(
            f"🎉 JOIN ({len(g['participants'])})",
            callback_data="join"
        )]
    ]

    await message.reply_text(
        giveaway_text(g),
        reply_markup=InlineKeyboardMarkup(buttons),
    )


async def giveaway(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_giveaway_message(update.message, context)


async def newgiveaway(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not admin(update.effective_user.id):
        await update.message.reply_text("⛔ Admin only.")
        return

    if len(context.args) < 3:
        await update.message.reply_text(
            "Usage:\n"
            "/newgiveaway <prize> <minutes> <title>\n\n"
            "Example:\n"
            "/newgiveaway TG_Premium 60 EliteX Premium Giveaway"
        )
        return

    prize = context.args[0]

    try:
        minutes = int(context.args[1])
        if minutes < 1:
            raise ValueError
    except ValueError:
        await update.message.reply_text("❌ Minutes must be a positive number.")
        return

    title = " ".join(context.args[2:])

    data["active"] = {
        "title": title,
        "prize": prize,
        "end": (
            datetime.now(timezone.utc) + timedelta(minutes=minutes)
        ).isoformat(),
        "participants": [],
    }
    save_data()

    await update.message.reply_text("✅ Giveaway created!")
    await show_giveaway_message(update.message, context)


async def endgiveaway(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not admin(update.effective_user.id):
        await update.message.reply_text("⛔ Admin only.")
        return

    if not data.get("active"):
        await update.message.reply_text("There is no active giveaway.")
        return

    await finish_giveaway(context, chat_id=update.effective_chat.id)


async def join(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    g = data.get("active")
    if not g:
        await query.answer("No active giveaway.", show_alert=True)
        return

    if datetime.fromisoformat(g["end"]) <= datetime.now(timezone.utc):
        await finish_giveaway(context, chat_id=query.message.chat_id)
        await query.answer("The giveaway has ended.", show_alert=True)
        return

    user_id = str(query.from_user.id)

    if user_id in g["participants"]:
        await query.answer("You already joined! 🎉", show_alert=True)
        return

    g["participants"].append(user_id)
    save_data()

    await query.answer("✅ You joined the giveaway!", show_alert=True)

    buttons = [[InlineKeyboardButton(
        f"🎉 JOIN ({len(g['participants'])})",
        callback_data="join"
    )]]

    try:
        await query.message.edit_text(
            giveaway_text(g),
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    except Exception:
        pass


async def finish_giveaway(context, chat_id=None):
    g = data.get("active")
    if not g:
        return

    participants = g["participants"]

    if participants:
        winner = random.choice(participants)
        text = (
            "🏆 ELITEX GIVEAWAYS WINNER 🏆\n\n"
            f"🎁 Prize: {g['prize']}\n"
            f"👤 Winner ID: {winner}\n"
            f"👥 Total entries: {len(participants)}"
        )
    else:
        text = (
            "⏰ Giveaway ended.\n\n"
            "Unfortunately, nobody joined."
        )

    data["active"] = None
    save_data()

    target = chat_id
    if target is None and context.job:
        target = context.job.chat_id

    if target:
        await context.bot.send_message(chat_id=target, text=text)


async def check_giveaway(context: ContextTypes.DEFAULT_TYPE):
    g = data.get("active")
    if not g:
        return

    if datetime.fromisoformat(g["end"]) <= datetime.now(timezone.utc):
        await finish_giveaway(context)


async def buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query

    if query.data == "join":
        await join(update, context)
    elif query.data == "view":
        await query.answer()
        await show_giveaway_message(query.message, context)
    elif query.data == "help":
        await query.answer()
        await query.message.reply_text(
            "/start - Start\n"
            "/giveaway - View giveaway\n"
            "/newgiveaway - Admin create giveaway\n"
            "/endgiveaway - Admin end giveaway"
        )


def main():
    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("giveaway", giveaway))
    app.add_handler(CommandHandler("newgiveaway", newgiveaway))
    app.add_handler(CommandHandler("endgiveaway", endgiveaway))
    app.add_handler(CallbackQueryHandler(buttons))

    if app.job_queue:
        app.job_queue.run_repeating(
            check_giveaway,
            interval=30,
            first=5,
        )

    print("✅ EliteXGiveaways is running...")
    app.run_polling()


if __name__ == "__main__":
    main()
